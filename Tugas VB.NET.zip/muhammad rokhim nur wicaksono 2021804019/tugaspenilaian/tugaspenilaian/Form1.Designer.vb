﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtnpm = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.txtabsensi = New System.Windows.Forms.TextBox()
        Me.txttugas = New System.Windows.Forms.TextBox()
        Me.cmbsemester = New System.Windows.Forms.ComboBox()
        Me.cmbjurusan = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtnilaiakhir = New System.Windows.Forms.TextBox()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnproses = New System.Windows.Forms.Button()
        Me.txtgrade = New System.Windows.Forms.TextBox()
        Me.txtipk = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtuas = New System.Windows.Forms.TextBox()
        Me.txtuts = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.cmbmatkul = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtindex = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtips = New System.Windows.Forms.TextBox()
        Me.txtip = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Cambria", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(238, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(242, 22)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Form Penilaian Mahasiswa"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(29, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "NPM"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(29, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Nama"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(357, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Semester"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(357, 114)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Jurusan"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 35)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Absensi"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 74)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Nilai Tugas"
        '
        'txtnpm
        '
        Me.txtnpm.Location = New System.Drawing.Point(98, 84)
        Me.txtnpm.Name = "txtnpm"
        Me.txtnpm.Size = New System.Drawing.Size(227, 20)
        Me.txtnpm.TabIndex = 7
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(98, 116)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(227, 20)
        Me.txtnama.TabIndex = 8
        '
        'txtabsensi
        '
        Me.txtabsensi.Location = New System.Drawing.Point(130, 28)
        Me.txtabsensi.Name = "txtabsensi"
        Me.txtabsensi.Size = New System.Drawing.Size(141, 20)
        Me.txtabsensi.TabIndex = 9
        '
        'txttugas
        '
        Me.txttugas.Location = New System.Drawing.Point(130, 71)
        Me.txttugas.Name = "txttugas"
        Me.txttugas.Size = New System.Drawing.Size(141, 20)
        Me.txttugas.TabIndex = 10
        '
        'cmbsemester
        '
        Me.cmbsemester.FormattingEnabled = True
        Me.cmbsemester.Location = New System.Drawing.Point(421, 79)
        Me.cmbsemester.Name = "cmbsemester"
        Me.cmbsemester.Size = New System.Drawing.Size(201, 21)
        Me.cmbsemester.TabIndex = 11
        '
        'cmbjurusan
        '
        Me.cmbjurusan.FormattingEnabled = True
        Me.cmbjurusan.Location = New System.Drawing.Point(421, 111)
        Me.cmbjurusan.Name = "cmbjurusan"
        Me.cmbjurusan.Size = New System.Drawing.Size(201, 21)
        Me.cmbjurusan.TabIndex = 12
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.txtip)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.txtindex)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txtips)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtnilaiakhir)
        Me.GroupBox1.Controls.Add(Me.btnclear)
        Me.GroupBox1.Controls.Add(Me.btnproses)
        Me.GroupBox1.Controls.Add(Me.txtgrade)
        Me.GroupBox1.Controls.Add(Me.txtipk)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtuas)
        Me.GroupBox1.Controls.Add(Me.txtuts)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtabsensi)
        Me.GroupBox1.Controls.Add(Me.txttugas)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 210)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(659, 265)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Hasil"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(343, 156)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(24, 13)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "IPS"
        '
        'txtnilaiakhir
        '
        Me.txtnilaiakhir.Location = New System.Drawing.Point(449, 28)
        Me.txtnilaiakhir.Name = "txtnilaiakhir"
        Me.txtnilaiakhir.ReadOnly = True
        Me.txtnilaiakhir.Size = New System.Drawing.Size(141, 20)
        Me.txtnilaiakhir.TabIndex = 24
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(169, 194)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(102, 53)
        Me.btnclear.TabIndex = 22
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnproses
        '
        Me.btnproses.Location = New System.Drawing.Point(35, 194)
        Me.btnproses.Name = "btnproses"
        Me.btnproses.Size = New System.Drawing.Size(102, 53)
        Me.btnproses.TabIndex = 21
        Me.btnproses.Text = "Proses"
        Me.btnproses.UseVisualStyleBackColor = True
        '
        'txtgrade
        '
        Me.txtgrade.Location = New System.Drawing.Point(449, 227)
        Me.txtgrade.Name = "txtgrade"
        Me.txtgrade.ReadOnly = True
        Me.txtgrade.Size = New System.Drawing.Size(141, 20)
        Me.txtgrade.TabIndex = 20
        '
        'txtipk
        '
        Me.txtipk.Location = New System.Drawing.Point(449, 71)
        Me.txtipk.Name = "txtipk"
        Me.txtipk.ReadOnly = True
        Me.txtipk.Size = New System.Drawing.Size(141, 20)
        Me.txtipk.TabIndex = 19
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(343, 230)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 17
        Me.Label12.Text = "Grade"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(343, 74)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(58, 13)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "Nilai Bobot"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(343, 35)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 13)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Nilai Akhir"
        '
        'txtuas
        '
        Me.txtuas.Location = New System.Drawing.Point(130, 153)
        Me.txtuas.Name = "txtuas"
        Me.txtuas.Size = New System.Drawing.Size(141, 20)
        Me.txtuas.TabIndex = 14
        '
        'txtuts
        '
        Me.txtuts.Location = New System.Drawing.Point(130, 111)
        Me.txtuts.Name = "txtuts"
        Me.txtuts.Size = New System.Drawing.Size(141, 20)
        Me.txtuts.TabIndex = 13
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 156)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Nilai UAS"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 114)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Nilai UTS"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Location = New System.Drawing.Point(29, 154)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 13)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "Mata Kuliah"
        '
        'cmbmatkul
        '
        Me.cmbmatkul.FormattingEnabled = True
        Me.cmbmatkul.Location = New System.Drawing.Point(98, 151)
        Me.cmbmatkul.Name = "cmbmatkul"
        Me.cmbmatkul.Size = New System.Drawing.Size(227, 21)
        Me.cmbmatkul.TabIndex = 15
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(343, 114)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 13)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "SKS"
        '
        'txtindex
        '
        Me.txtindex.Location = New System.Drawing.Point(449, 111)
        Me.txtindex.Name = "txtindex"
        Me.txtindex.ReadOnly = True
        Me.txtindex.Size = New System.Drawing.Size(141, 20)
        Me.txtindex.TabIndex = 28
        Me.txtindex.Text = "3"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(343, 194)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(24, 13)
        Me.Label16.TabIndex = 29
        Me.Label16.Text = "IPK"
        '
        'txtips
        '
        Me.txtips.Location = New System.Drawing.Point(449, 153)
        Me.txtips.Name = "txtips"
        Me.txtips.ReadOnly = True
        Me.txtips.Size = New System.Drawing.Size(141, 20)
        Me.txtips.TabIndex = 26
        '
        'txtip
        '
        Me.txtip.Location = New System.Drawing.Point(449, 191)
        Me.txtip.Name = "txtip"
        Me.txtip.ReadOnly = True
        Me.txtip.Size = New System.Drawing.Size(141, 20)
        Me.txtip.TabIndex = 30
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(724, 530)
        Me.Controls.Add(Me.cmbmatkul)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmbjurusan)
        Me.Controls.Add(Me.cmbsemester)
        Me.Controls.Add(Me.txtnama)
        Me.Controls.Add(Me.txtnpm)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Penilaian Mahasiswa"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtnpm As TextBox
    Friend WithEvents txtnama As TextBox
    Friend WithEvents txtabsensi As TextBox
    Friend WithEvents txttugas As TextBox
    Friend WithEvents cmbsemester As ComboBox
    Friend WithEvents cmbjurusan As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtuas As TextBox
    Friend WithEvents txtuts As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents btnclear As Button
    Friend WithEvents btnproses As Button
    Friend WithEvents txtgrade As TextBox
    Friend WithEvents txtipk As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents cmbmatkul As ComboBox
    Friend WithEvents txtnilaiakhir As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtip As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtindex As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtips As TextBox
End Class
