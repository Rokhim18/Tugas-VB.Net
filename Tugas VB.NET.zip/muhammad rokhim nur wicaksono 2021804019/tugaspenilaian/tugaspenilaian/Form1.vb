﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbsemester.Items.Add("1")
        cmbsemester.Items.Add("2")
        cmbsemester.Items.Add("3")
        cmbsemester.Items.Add("4")
        cmbsemester.Items.Add("5")
        cmbsemester.Items.Add("6")
        cmbsemester.Items.Add("7")
        cmbsemester.Items.Add("8")
        cmbjurusan.Items.Add("Sistem Informasi")
        cmbjurusan.Items.Add("Sistem Informasi Akuntansi")
        cmbjurusan.Items.Add("Rekayasa Perangkat Lunak")
        cmbjurusan.Items.Add("Manajemen")
        cmbmatkul.Items.Add("Pemograman VB.NET")
        cmbmatkul.Items.Add("Perancangan Sistem Informasi")
        cmbmatkul.Items.Add("Pemograman Berbasis Objek")
        cmbmatkul.Items.Add("Jaringan Komputer")
        cmbmatkul.Items.Add("Statistik 2")
        cmbmatkul.Items.Add("Aplikasi Game")
        cmbmatkul.Items.Add("Perangkat Komputer")

    End Sub

    Private Sub btnproses_Click(sender As Object, e As EventArgs) Handles btnproses.Click
        Dim nilai1, nilai2, nilai3, nilai4 As Integer
        nilai1 = Integer.Parse(txtabsensi.Text)
        nilai2 = Integer.Parse(txttugas.Text)
        nilai3 = Integer.Parse(txtuts.Text)
        nilai4 = Integer.Parse(txtuas.Text)
        txtnilaiakhir.Text = ((nilai1 * 10 / 16) + (nilai2 * 20 / 100) + (nilai3 * 30 / 100) + (nilai4 * 40 / 100))
        If txtabsensi.Text >= 16 Then
            txtabsensi.Text = "0"
        ElseIf txttugas.Text >= 100 Then
            txttugas.Text = "0"
        ElseIf txtuts.Text >= 100 Then
            txtuts.Text = "0"
        ElseIf txtuas.Text >= 100 Then
            txtuas.Text = "0"
        End If
        bobot()
        grade()
        ips()
        ipk()
    End Sub

    Private Sub bobot()
        If txtnilaiakhir.Text >= 90 Then
            txtipk.Text = "4"
        ElseIf txtnilaiakhir.Text >= 85 Then
            txtipk.Text = "3.75"
        ElseIf txtnilaiakhir.Text >= 80 Then
            txtipk.Text = "3.5"
        ElseIf txtnilaiakhir.Text >= 75 Then
            txtipk.Text = "3.25"
        ElseIf txtnilaiakhir.Text >= 70 Then
            txtipk.Text = "3"
        ElseIf txtnilaiakhir.Text >= 65 Then
            txtipk.Text = "2.75"
        ElseIf txtnilaiakhir.Text >= 60 Then
            txtipk.Text = "2.5"
        ElseIf txtnilaiakhir.Text >= 55 Then
            txtipk.Text = "2.25"
        ElseIf txtnilaiakhir.Text >= 50 Then
            txtipk.Text = "2"
        ElseIf txtnilaiakhir.Text >= 45 Then
            txtipk.Text = "1.75"
        ElseIf txtnilaiakhir.Text >= 40 Then
            txtipk.Text = "1.5"
        ElseIf txtnilaiakhir.Text >= 35 Then
            txtipk.Text = "1.25"
        ElseIf txtnilaiakhir.Text >= 30 Then
            txtipk.Text = "1"
        ElseIf txtnilaiakhir.Text <= 30 Then
            txtipk.Text = "0"
        End If
    End Sub

    Private Sub grade()
        If txtnilaiakhir.Text >= 90 Then
            txtgrade.Text = "A+"
        ElseIf txtnilaiakhir.Text >= 85 Then
            txtgrade.Text = "A"
        ElseIf txtnilaiakhir.Text >= 80 Then
            txtgrade.Text = "A-"
        ElseIf txtnilaiakhir.Text >= 75 Then
            txtgrade.Text = "B+"
        ElseIf txtnilaiakhir.Text >= 70 Then
            txtgrade.Text = "B"
        ElseIf txtnilaiakhir.Text >= 65 Then
            txtgrade.Text = "B-"
        ElseIf txtnilaiakhir.Text >= 60 Then
            txtgrade.Text = "C+"
        ElseIf txtnilaiakhir.Text >= 55 Then
            txtgrade.Text = "C"
        ElseIf txtnilaiakhir.Text >= 50 Then
            txtgrade.Text = "C-"
        ElseIf txtnilaiakhir.Text >= 45 Then
            txtgrade.Text = "D+"
        ElseIf txtnilaiakhir.Text >= 40 Then
            txtgrade.Text = "D"
        ElseIf txtnilaiakhir.Text >= 35 Then
            txtgrade.Text = "D-"
        ElseIf txtnilaiakhir.Text <= 30 Then
            txtgrade.Text = "E"
        End If
    End Sub

    Private Sub ips()
        txtips.Text = txtipk.Text * txtindex.Text / txtindex.Text
    End Sub

    Private Sub ipk()
        txtip.Text = txtips.Text / 1
        '1 adalah jumlah ips pada semester tersebut
        'jika ips lebih dari 1 maka cara mencari ipk dengan cara menjumlahkan seluruh ips dari setiap semester / jumlah semester
    End Sub


    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        txtnpm.Clear()
        txtnama.Clear()
        txtabsensi.Clear()
        txttugas.Clear()
        txtuts.Clear()
        txtuas.Clear()
        txtnilaiakhir.Clear()
        txtipk.Clear()
        txtgrade.Clear()
        txtips.Clear()
        txtip.Clear()
        cmbmatkul.Text = ""
        cmbjurusan.Text = ""
        cmbsemester.Text = ""
    End Sub


End Class
